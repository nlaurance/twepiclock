# Metadata for the widget EGG. Should leave it for the (unimplemented) widget
# tracker to track it

__DISTRIBUTION__ = 'tw.epiclock'
__DESCRIPTION__ = 'Insert Clocks in templates'
__URL__ = ''
__VERSION__ = '0.1a0'
__AUTHOR__ = 'Nicolas Laurance'
__EMAIL__ = 'nicolas.laurance<at>gmail'
__COPYRIGHT__ = "Copyright 2010 Nicolas Laurance"
__LICENSE__ = ''
